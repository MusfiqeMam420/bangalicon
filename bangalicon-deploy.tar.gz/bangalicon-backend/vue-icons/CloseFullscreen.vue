<script setup>
defineProps({
  size: {
    type: [Number, String],
    default: 24,
  },
  color: {
    type: String,
    default: "currentColor",
  },
});
</script>

<template>
  <svg
    :width="size"
    :height="size"
    viewBox="0 0 1000 1000"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    :style="{ color }"
  >
    <path d="M372 532l56 56-240 240q-17 17-39 10a42 42 0 0 1-28-27q-7-21 11-39z m27-12q18 0 29 12 12 11 12 29v246q0 25-20 35-20 9-40 0-20-10-20-35V600H153q-25 0-35-20a46.8 46.8 0 0 1 0-40q10-20 35-20z m189-92l-56-56 240-240q17-17 38-10 22 7 29 28 7 20-11 38z m-27 12q-18 0-30-11-11-12-11-30V152q0-24 20-34a42.400000000000006 42.400000000000006 0 0 1 40 0q20 10 20 34V360h208q24 0 34 20t0 40-34 20z"/>
  </svg>
</template>
