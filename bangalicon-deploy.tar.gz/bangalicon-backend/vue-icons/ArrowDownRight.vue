<script setup>
defineProps({
  size: {
    type: [Number, String],
    default: 24,
  },
  color: {
    type: String,
    default: "currentColor",
  },
});
</script>

<template>
  <svg
    :width="size"
    :height="size"
    viewBox="0 0 1000 1000"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    :style="{ color }"
  >
    <path d="M748 692l-56 56-480-480q-17-17-10-38a42 42 0 0 1 27-28q21-8 39 10z m12 27q0 18-12 30-11 11-29 11H320q-25 0-35-20a46.8 46.8 0 0 1 0-40q10-20 35-20h360V320q0-25 20-34a42.400000000000006 42.400000000000006 0 0 1 40 0q20 9 20 34z"/>
  </svg>
</template>
