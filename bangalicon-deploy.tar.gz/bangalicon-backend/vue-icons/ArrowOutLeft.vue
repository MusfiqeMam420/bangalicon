<script setup>
defineProps({
  size: {
    type: [Number, String],
    default: 24,
  },
  color: {
    type: String,
    default: "currentColor",
  },
});
</script>

<template>
  <svg
    :width="size"
    :height="size"
    viewBox="0 0 1000 1000"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    :style="{ color }"
  >
    <path d="M680 120q43 0 80 22 37 21 58 58 22 37 22 80v400q0 43-22 80A158.8 158.8 0 0 1 760 819 160 160 0 0 1 680 840h-40q-25 0-35-20a46.8 46.8 0 0 1 0-40q10-20 35-20h40q37 0 58-21 22-22 22-59V280q0-37-22-58Q717 200 680 200h-40q-18 0-29-12a42.400000000000006 42.400000000000006 0 0 1-10-28q0-16 10-28Q622 120 640 120zM348 612q17 17 10 39-7 21-28 28-20 7-38-11l-160-159Q119 496 119 480t13-29l160-159q17-17 38-10 22 7 29 28 7 20-11 38L217 480zM160 520v-80h480q25 0 34 20 10 20 0 40-9 20-34 20z"/>
  </svg>
</template>
