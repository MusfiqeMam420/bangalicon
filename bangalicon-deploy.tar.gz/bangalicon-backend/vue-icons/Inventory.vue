<script setup>
defineProps({
  size: {
    type: [Number, String],
    default: 24,
  },
  color: {
    type: String,
    default: "currentColor",
  },
});
</script>

<template>
  <svg
    :width="size"
    :height="size"
    viewBox="0 0 1000 1000"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    :style="{ color }"
  >
    <path d="M280 840a164 164 0 0 1-82-21 156 156 0 0 1-57-57A164 164 0 0 1 120 680V342q0-15 3-30 4-15 11-30l40-80q20-39 55-60Q265 120 306 120h348q41 0 76 22 36 21 56 59l40 81q7 15 10 30 4 15 4 30V680a164 164 0 0 1-21 82 153.6 153.6 0 0 1-58 57Q725 840 680 840z m400-80q40 0 60-20T760 680V342a64 64 0 0 0-1-12 40 40 0 0 0-5-12v-1l-39-79a96 96 0 0 0-10-15 64 64 0 0 0-11-12 44 44 0 0 0-18-8A72 72 0 0 0 654 200h-348q-13 0-22 3-9 2-18 8-6 5-11 12-5 6-10 15L206 317v1q-3 7-5 12a64 64 0 0 0-1 12V680q0 40 20 60T280 760zM160 280h640v80H160z"/>
  </svg>
</template>
