<script setup>
defineProps({
  size: {
    type: [Number, String],
    default: 24,
  },
  color: {
    type: String,
    default: "currentColor",
  },
});
</script>

<template>
  <svg
    :width="size"
    :height="size"
    viewBox="0 0 1000 1000"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    :style="{ color }"
  >
    <path d="M701 155q32-10 60 3 28 12 40 41 13.040000000000001 28 3 59l-100 278-62-62 93-261q2-8 8-5a12 12 0 0 1 8 8q3 5-5 8l-263 91-62-62zM158 485q-29-16-38-46t5-58A80 80 0 0 1 170 340l168-59L400 344l-220 77q-7 3-10-2a10.8 10.8 0 0 1 1-10q3-6 10-2l232 133q6 3 8 8l120 237q3 7-2 10a10.8 10.8 0 0 1-9 0q-5-2-2-9l84-230 62 61-65 181q-12 32-41 46a81.19999999999999 81.19999999999999 0 0 1-60 3q-31-10-46-41L358 600zM92 148q-18-18-11-38 7-21 28-28 22-7 39 10l720 720q17 17 10 39-7.039999999999999 21-27 28T812 868z"/>
  </svg>
</template>
