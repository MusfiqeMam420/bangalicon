<script setup>
defineProps({
  size: {
    type: [Number, String],
    default: 24,
  },
  color: {
    type: String,
    default: "currentColor",
  },
});
</script>

<template>
  <svg
    :width="size"
    :height="size"
    viewBox="0 0 1000 1000"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    :style="{ color }"
  >
    <path d="M280 840a160 160 0 0 1-80-21A168 168 0 0 1 141 760 160 160 0 0 1 120 680V280q0-43 21-80A158.8 158.8 0 0 1 200 142 154 154 0 0 1 280 120h40q25 0 34 20 10 20 0 40Q345 200 320 200H280q-37 0-59 22Q200 243 200 280v400q0 37 21 59Q243 760 280 760h40q19 0 29 12t10 28-10 28T320 840z m332-492q-17-17-10-38 7-22 27-29 21-7 39 11l160 159q13 13 13 29t-13 29l-160 159q-17 17-39 10a42 42 0 0 1-28-27q-7-21 11-39l131-132zM800 440v80H320q-25 0-35-20a46.8 46.8 0 0 1 0-40q10-20 35-20z"/>
  </svg>
</template>
