<script setup>
defineProps({
  size: {
    type: [Number, String],
    default: 24,
  },
  color: {
    type: String,
    default: "currentColor",
  },
});
</script>

<template>
  <svg
    :width="size"
    :height="size"
    viewBox="0 0 1000 1000"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    :style="{ color }"
  >
    <path d="M720 648l-81 204q-7 11-18 20-11 8-26 8h-13q-40 0-73-18a144 144 0 0 1-51-51Q440 778 440 738v-92q0-4 10 5 11 8 19 19 9 10 5 10H252q-49 0-86-24-36-24-53-64-17-41-8-89l36-202q6-39 31-71 26-33 62-51A164 164 0 0 1 310 160H720zM720 160q44 0 81 21t58 58T880 320v200q0 44-21 81a161.20000000000002 161.20000000000002 0 0 1-58 58A161.20000000000002 161.20000000000002 0 0 1 720 680h-80V160z m0 80v360q25 0 43-9 18-10 27-28 10-18 10-43V320q0-25-10-43-9-18-27-27Q745 240 720 240"/>
  </svg>
</template>
