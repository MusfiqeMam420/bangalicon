<script setup>
defineProps({
  size: {
    type: [Number, String],
    default: 24,
  },
  color: {
    type: String,
    default: "currentColor",
  },
});
</script>

<template>
  <svg
    :width="size"
    :height="size"
    viewBox="0 0 1000 1000"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    :style="{ color }"
  >
    <path d="M240 800q-75 0-118-42Q80 715 80 640v-61q0-23 13-38 14-16 37-22 11-3 17-7a28 28 0 0 0 10-12Q160 492 160 480t-3-19a22.400000000000002 22.400000000000002 0 0 0-10-12A56 56 0 0 0 130 440q-23-5-37-20Q80 404 80 381V320q0-76 42-118Q165 160 240 160h480q75 0 117 42Q880 244 880 320v320q0 75-43 118Q795 800 720 800z m280-264l62 62q18 18 38 11 21-8 28-29t-10-38L576 480l62-62q17-17 10-38-7-22-28-29-20-7-38 11L520 424l-62-62q-18-18-39-10-20 7-27 28t10 38L464 480l-62 62q-18 18-11 39 8 20 29 27t38-10z"/>
  </svg>
</template>
