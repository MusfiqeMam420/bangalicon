<script setup>
defineProps({
  size: {
    type: [Number, String],
    default: 24,
  },
  color: {
    type: String,
    default: "currentColor",
  },
});
</script>

<template>
  <svg
    :width="size"
    :height="size"
    viewBox="0 0 1000 1000"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    :style="{ color }"
  >
    <path d="M59.76 57.32h399.04v399.04H59.76z m440.67999999999995 0h399v399.04H500.4zM59.76 498h399.04v399H59.76z m440.67999999999995 0h399v399H500.4z"/>
  </svg>
</template>
