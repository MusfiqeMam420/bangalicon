<script setup>
defineProps({
  size: {
    type: [Number, String],
    default: 24,
  },
  color: {
    type: String,
    default: "currentColor",
  },
});
</script>

<template>
  <svg
    :width="size"
    :height="size"
    viewBox="0 0 1000 1000"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    :style="{ color }"
  >
    <path d="M480 743l252-251q18-18 38-10 21 7 28 28t-10 38l-279 280q-13 13-29 13t-29-13l-279-280q-18-18-11-38 8-21 29-28t38 10zM440 160q0-25 20-34a42.400000000000006 42.400000000000006 0 0 1 40 0q20 9 20 34v640h-80z"/>
  </svg>
</template>
