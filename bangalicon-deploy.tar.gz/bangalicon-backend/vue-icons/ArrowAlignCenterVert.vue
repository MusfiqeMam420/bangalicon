<script setup>
defineProps({
  size: {
    type: [Number, String],
    default: 24,
  },
  color: {
    type: String,
    default: "currentColor",
  },
});
</script>

<template>
  <svg
    :width="size"
    :height="size"
    viewBox="0 0 1000 1000"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    :style="{ color }"
  >
    <path d="M200 520q-25 0-35-20a46.8 46.8 0 0 1 0-40q10-20 35-20h560q25 0 34 20 10 20 0 40-9 20-34 20z m412-348q17-17 38-10 22 7 29 28 7 20-11 38l-159 160q-13 13-29 13t-29-13L292 228q-17-17-10-38 7-22 27-29 21-7 39 11L480 303zM520 360h-80V80q0-25 20-34a42.400000000000006 42.400000000000006 0 0 1 40 0q20 9 20 34zM348 788q-17 17-39 10a42 42 0 0 1-28-27q-7-21 11-39l159-160q13-13 29-13t29 13l159 160q17 17 10 39-7 21-28 28-20 7-38-11L480 657zM440 600h80v280q0 25-20 35-20 9-40 0-20-10-20-35z"/>
  </svg>
</template>
