<script setup>
defineProps({
  size: {
    type: [Number, String],
    default: 24,
  },
  color: {
    type: String,
    default: "currentColor",
  },
});
</script>

<template>
  <svg
    :width="size"
    :height="size"
    viewBox="0 0 1000 1000"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    :style="{ color }"
  >
    <path d="M320 880a160 160 0 0 1-80-21A168 168 0 0 1 181 800 160 160 0 0 1 160 720V240q0-43 21-80A158.8 158.8 0 0 1 240 102 154 154 0 0 1 320 80h203q7 0 12 3 6 2 11 6l245 245a36 36 0 0 1 6 11q3 5 3 12V720q0 43-22 80A158.8 158.8 0 0 1 720 859 160 160 0 0 1 640 880z m343-560L560 217V320z m-252 347q13 13 29 14 16 0 29-13l159-160q17-17 10-38-7-22-28-29-20-7-38 11L440 583 388 532q-18-18-39-11-20 7-27 29-7 21 10 38z"/>
  </svg>
</template>
