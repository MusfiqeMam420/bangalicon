<script setup>
defineProps({
  size: {
    type: [Number, String],
    default: 24,
  },
  color: {
    type: String,
    default: "currentColor",
  },
});
</script>

<template>
  <svg
    :width="size"
    :height="size"
    viewBox="0 0 1000 1000"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    :style="{ color }"
  >
    <path d="M120 640q0-19 12-29t28-10 28 10T200 640v40q0 37 21 59Q243 760 280 760h400q37 0 58-21 22-22 22-59v-40q0-25 20-34a42.400000000000006 42.400000000000006 0 0 1 40 0q20 9 20 34v40q0 43-22 80A158.8 158.8 0 0 1 760 819 160 160 0 0 1 680 840H280a160 160 0 0 1-80-21A168 168 0 0 1 141 760 160 160 0 0 1 120 680z m360-57l132-131q18-18 38-11 21 7 28 29 7 21-10 38l-159 160q-13 13-29 13t-29-13l-159-160q-18-18-11-38 7-21 28-28 22-7 39 10zM440 160q0-25 20-34a42.400000000000006 42.400000000000006 0 0 1 40 0q20 9 20 34v480h-80z"/>
  </svg>
</template>
