<script setup>
defineProps({
  size: {
    type: [Number, String],
    default: 24,
  },
  color: {
    type: String,
    default: "currentColor",
  },
});
</script>

<template>
  <svg
    :width="size"
    :height="size"
    viewBox="0 0 1000 1000"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    :style="{ color }"
  >
    <path d="M280 840a160 160 0 0 1-80-21A168 168 0 0 1 141 760 160 160 0 0 1 120 680V280q0-43 21-80A158.8 158.8 0 0 1 200 142 154 154 0 0 1 280 120h40q25 0 34 20 10 20 0 40Q345 200 320 200H280q-37 0-59 22Q200 243 200 280v400q0 37 21 59Q243 760 280 760h40q19 0 29 12t10 28-10 28T320 840z m228-228q17 17 10 39-7 21-28 28-20 7-38-11l-160-159Q279 496 279 480t13-29l160-159q17-17 38-10 22 7 29 28 7 20-11 38L377 480zM320 520v-80h480q25 0 34 20 10 20 0 40-9 20-34 20z"/>
  </svg>
</template>
