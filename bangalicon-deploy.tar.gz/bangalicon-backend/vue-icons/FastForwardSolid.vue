<script setup>
defineProps({
  size: {
    type: [Number, String],
    default: 24,
  },
  color: {
    type: String,
    default: "currentColor",
  },
});
</script>

<template>
  <svg
    :width="size"
    :height="size"
    viewBox="0 0 1000 1000"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    :style="{ color }"
  >
    <path d="M210 706a58.4 58.4 0 0 1-41 7 58.4 58.4 0 0 1-35-21 60 60 0 0 1-14-39v-346q0-23 14-39 14-17 35-21a58.4 58.4 0 0 1 41 7l300 174q19 11 26 32 8 20 0 41a56 56 0 0 1-26 31z m360 0a58.4 58.4 0 0 1-41 7 58.4 58.4 0 0 1-35-21 60 60 0 0 1-14-39v-346q0-23 14-39 14-17 35-21a58.4 58.4 0 0 1 41 7l300 174q19 11 26 32 8 20 0 41a56 56 0 0 1-26 31z"/>
  </svg>
</template>
