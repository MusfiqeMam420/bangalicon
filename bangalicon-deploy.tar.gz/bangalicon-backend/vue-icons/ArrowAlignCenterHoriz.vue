<script setup>
defineProps({
  size: {
    type: [Number, String],
    default: 24,
  },
  color: {
    type: String,
    default: "currentColor",
  },
});
</script>

<template>
  <svg
    :width="size"
    :height="size"
    viewBox="0 0 1000 1000"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    :style="{ color }"
  >
    <path d="M440 200q0-25 20-34a42.400000000000006 42.400000000000006 0 0 1 40 0q20 9 20 34v560q0 25-20 35-20 9-40 0-20-10-20-35z m348 412q17 17 10 39-7 21-28 28-20 7-38-11l-160-159q-13-13-13-29t13-29l160-159q17-17 38-10 22 7 29 28 7 20-11 38L657 480zM600 520v-80h280q25 0 34 20 10 20 0 40-9 20-34 20zM172 348q-17-17-10-38 7.039999999999999-22 27-29 21-7 39 11l160 159q13 13 13 29t-13 29l-160 159q-17 17-39 10a42 42 0 0 1-28-27q-7-21 11-39L303 480zM360 440v80H80q-25 0-35-20a46.8 46.8 0 0 1 0-40q10-20 35-20z"/>
  </svg>
</template>
