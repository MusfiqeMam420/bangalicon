<script setup>
defineProps({
  size: {
    type: [Number, String],
    default: 24,
  },
  color: {
    type: String,
    default: "currentColor",
  },
});
</script>

<template>
  <svg
    :width="size"
    :height="size"
    viewBox="0 0 1000 1000"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    :style="{ color }"
  >
    <path d="M240 800a160 160 0 0 1-80-21A168 168 0 0 1 101 720 160 160 0 0 1 80 640V280q0-43 21-80A158.8 158.8 0 0 1 160 142 154 154 0 0 1 240 120h148q15 0 27 5t23 16L497 200H720q43 0 80 22 37 21 58 58 22 37 22 80v280q0 43-22 80A158.8 158.8 0 0 1 800 779 160 160 0 0 1 720 800z m480-80q37 0 58-21 22-22 22-59V360q0-37-22-58Q757 280 720 280h-228a68 68 0 0 1-27-5 76 76 0 0 1-22-16L383 200H240q-37 0-59 22Q160 243 160 280v360q0 37 21 59Q203 720 240 720z m-360-200q-25 0-35-20a46.8 46.8 0 0 1 0-40q10-20 35-20h240q25 0 34 20 10 20 0 40-9 20-34 20z"/>
  </svg>
</template>
