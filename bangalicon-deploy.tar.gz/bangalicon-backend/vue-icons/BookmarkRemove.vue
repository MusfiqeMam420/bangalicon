<script setup>
defineProps({
  size: {
    type: [Number, String],
    default: 24,
  },
  color: {
    type: String,
    default: "currentColor",
  },
});
</script>

<template>
  <svg
    :width="size"
    :height="size"
    viewBox="0 0 1000 1000"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    :style="{ color }"
  >
    <path d="M160 240q0-43 21-80A158.8 158.8 0 0 1 240 102 154 154 0 0 1 320 80h320q43 0 80 22 37 21 58 58 22 37 22 80v586q0 17-11 30a46 46 0 0 1-26 17q-16 4-32-2L480 763l-251 108q-16 6-32 2a50.8 50.8 0 0 1-26-17A45.199999999999996 45.199999999999996 0 0 1 160 826z m80 586q0-2-1-3a40 40 0 0 1-2-5q-6-9-24-28l254-108A48 48 0 0 1 480 680q7 0 13 2l254 108q-16.96 19-24 28a40 40 0 0 1-2 5Q720 824 720 826V240q0-37-22-58Q677 160 640 160H320q-37 0-59 22Q240 203 240 240zM360 480q-25 0-35-20a46.8 46.8 0 0 1 0-40q10-20 35-20h240q25 0 34 20 10 20 0 40-9 20-34 20z"/>
  </svg>
</template>
