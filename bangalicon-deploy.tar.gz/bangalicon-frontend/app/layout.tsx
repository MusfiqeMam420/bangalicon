import "./globals.css";
import type { Metadata } from "next";
import ToastProvider from "@/components/ui/ToastProvider";
import AppShell from "./AppShell";
import {
  defaultDescription,
  defaultTitle,
  getSiteJsonLd,
  logoImage,
  shareImage,
  siteKeywords,
  siteName,
  siteUrl,
} from "./lib/seo";

const apiBase = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000/api";
const iconCssHref = `${apiBase.replace(/\/api\/?$/, "")}/cdn/free/bangalicon-free.css`;
const siteJsonLd = getSiteJsonLd();

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  applicationName: siteName,
  title: {
    default: defaultTitle,
    template: `%s | ${siteName}`,
  },
  description: defaultDescription,
  keywords: siteKeywords,
  authors: [{ name: siteName }],
  creator: siteName,
  publisher: siteName,
  category: "design",
  referrer: "origin-when-cross-origin",
  alternates: {
    canonical: "/",
  },
  manifest: "/manifest.webmanifest",
  icons: {
    icon: [{ url: logoImage, type: "image/png" }],
    shortcut: [{ url: logoImage, type: "image/png" }],
    apple: [{ url: logoImage, type: "image/png" }],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-snippet": -1,
      "max-image-preview": "large",
      "max-video-preview": -1,
    },
  },
  openGraph: {
    title: defaultTitle,
    description: defaultDescription,
    url: "/",
    siteName,
    type: "website",
    locale: "en_US",
    images: [
      {
        url: shareImage,
        alt: "Bangalicon social media preview",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: defaultTitle,
    description: defaultDescription,
    images: [shareImage],
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@200..800&display=swap"
          rel="stylesheet"
        />
        <link rel="stylesheet" href={iconCssHref} />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(siteJsonLd) }}
        />
      </head>

      <body className="bg-[#f5f6f8] text-gray-900 antialiased">
        <ToastProvider>
          <AppShell>{children}</AppShell>
        </ToastProvider>
      </body>
    </html>
  );
}
