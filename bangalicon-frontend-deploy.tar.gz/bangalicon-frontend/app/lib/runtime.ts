const LOCAL_SITE_URL = "http://localhost:3000";
const PROD_SITE_URL = "https://bangalicon.com";
const LOCAL_API_URL = "http://localhost:5000/api";
const PROD_API_URL = "https://api.bangalicon.com/api";

const normalizeUrl = (value: string) =>
  value.startsWith("http") ? value : `https://${value}`;

const isLocalHostname = (hostname: string) =>
  hostname === "localhost" ||
  hostname === "127.0.0.1" ||
  hostname === "0.0.0.0" ||
  hostname.endsWith(".local");

export const getPublicSiteUrl = () => {
  const envSiteUrl = process.env.NEXT_PUBLIC_SITE_URL || process.env.SITE_URL;

  if (envSiteUrl) {
    return normalizeUrl(envSiteUrl);
  }

  if (typeof window !== "undefined") {
    return isLocalHostname(window.location.hostname) ? LOCAL_SITE_URL : PROD_SITE_URL;
  }

  return process.env.NODE_ENV === "development" ? LOCAL_SITE_URL : PROD_SITE_URL;
};

export const getPublicApiBase = () => {
  const envApiUrl = process.env.NEXT_PUBLIC_API_URL || process.env.API_URL;

  if (envApiUrl) {
    return envApiUrl;
  }

  if (typeof window !== "undefined") {
    return isLocalHostname(window.location.hostname) ? LOCAL_API_URL : PROD_API_URL;
  }

  return process.env.NODE_ENV === "development" ? LOCAL_API_URL : PROD_API_URL;
};

export const getPublicCdnBase = () => getPublicApiBase().replace(/\/api\/?$/, "");
